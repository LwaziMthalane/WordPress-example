<?php get_header(); ?>
<main><section><div class="w"><?php while(have_posts()): the_post(); the_title('<h1>','</h1>'); the_content(); endwhile; ?></div></section></main>
<?php get_footer(); ?>
